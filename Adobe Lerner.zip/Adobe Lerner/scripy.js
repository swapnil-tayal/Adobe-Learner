// document.getElementById("name").onclick = function border(){
//     document.getElementById("name").style.border='0.1rem solid #f7427e';
// }
// document.getElementById("email").onclick = function border1(){
//     document.getElementById("email").style.border='0.1rem solid #f7427e';
// }
// document.getElementById("subject").onclick = function border2(){
//     document.getElementById("subject").style.border='0.1rem solid #f7427e';
// }
// document.getElementById("message").onclick = function border3(){
//     document.getElementById("message").style.border='0.1rem solid #f7427e';
// }

// function bor() {
//     document.getElementById("name").style.border="0.1rem solid #f7427e"
// }